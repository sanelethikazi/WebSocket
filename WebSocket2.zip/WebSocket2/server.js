const express = require('express');
const http = require('http');
const mysql = require('mysql2');
const socketIo = require('socket.io');
const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// MySQL connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '19980426',  
  database: 'status_app'
});

db.connect(err => {
  if (err) throw err;
  console.log('MySQL Connected...');
});

// Middleware
app.use(express.json());
app.use(express.static('public'));

// Handle new connections
io.on('connection', (socket) => {
  console.log('New client connected');

  // Fetch initial statuses
  db.query('SELECT * FROM statuses ORDER BY created_at DESC', (err, results) => {
    if (err) throw err;
    socket.emit('initialStatuses', results);
  });

  // Handle new status
  socket.on('newStatus', (status) => {
    const { user, statusText } = status;
    const query = 'INSERT INTO statuses (user, status) VALUES (?, ?)';
    db.query(query, [user, statusText], (err, result) => {
      if (err) throw err;
      io.emit('statusAdded', { id: result.insertId, user, status: statusText, created_at: new Date() });
    });
  });

  // Handle disconnection
  socket.on('disconnect', () => {
    console.log('Client disconnected');
  });
});

// Start the server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
